# EWAA — Enterprise Workflow Automation Agent

This repository contains backend, frontend, workflows, and documentation.